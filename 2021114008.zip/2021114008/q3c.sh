#!/bin/bash
wc --words < $1
