#!/bin/bash
stat --format="%s" $1