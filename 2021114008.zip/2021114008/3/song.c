#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "song.h"
struct Song *makeSong(char *name, char *artist, float duration)
{
    struct Song *a;
    a = (struct Song *)malloc(sizeof(struct Song));
    a->duration = duration;
    strcpy(a->artist,artist);
    strcpy(a->name,name);
    return a;
}

