#include<stdio.h>
#include<stdlib.h>

#ifndef SONG_H
#define SONG_H

struct Song
{
    char name[101];
    char artist[101];
    float duration;

};

struct Song * makeSong(char * name ,char * artist ,float duration);

#endif