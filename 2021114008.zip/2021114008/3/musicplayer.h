#include <stdio.h>
#include <stdlib.h>
#ifndef MUSICPLAYER_H
#define MUSICPLAccYER_H

struct MusicPlayer
{
    struct Song *Current_Song;
    struct Song **A;
    int nos;
};

struct MusicPlayer *createMusicPlayer(void);
int addSongToQueue(struct MusicPlayer *m1, struct Song *song);
int removeSongFromQueue(struct MusicPlayer *m1, int p);
int playSong(struct MusicPlayer *m1);
struct Song *getCurrentSong(struct MusicPlayer *m2);
#endif