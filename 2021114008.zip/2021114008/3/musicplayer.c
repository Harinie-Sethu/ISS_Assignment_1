#include <stdio.h>
#include <stdlib.h>
#include "musicplayer.h"

struct MusicPlayer *createMusicPlayer()
{
    struct MusicPlayer * temp = (struct MusicPlayer *)malloc(sizeof(struct MusicPlayer));
    temp->nos = 0;
    temp->Current_Song = NULL;
    temp->A = (struct Song **)malloc(1000*sizeof(struct Song *));
    return temp;
}

int addSongToQueue(struct MusicPlayer *m1, struct Song *song)
{
    m1->A[m1->nos++] = song;
    return 0;
}

int removeSongFromQueue(struct MusicPlayer *m1, int p)
{
    if (p >= m1->nos)
    {
        return 1;
    }
    for(int i= p+1 ; i<m1->nos;i++)
    {
        m1->A[i-1]=m1->A[i];
    }

    m1->nos = m1->nos -1;
    return 0;
}

int playSong(struct MusicPlayer *m1)
{
    m1->Current_Song = m1->A[0];

    for(int i= 1 ; i<m1->nos;i++)
    {
        m1->A[i-1]=m1->A[i];
    }

    m1->nos = m1->nos -1;
    return 0;
}

struct Song *getCurrentSong(struct MusicPlayer *m2)
{
    return m2->Current_Song;
}