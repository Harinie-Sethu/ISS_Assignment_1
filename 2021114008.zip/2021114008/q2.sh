#!/bin/bash
sed '/^$/d' quotes.txt | sort quotes.txt | uniq -u | awk -F '~' '{print $2  " once said, " "\"" $1 "\""  }'  > speech.txt
