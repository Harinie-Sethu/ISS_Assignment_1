#!/bin/bash
IFS=","
read -a name

for((i=0 ; i<${#name[*]} ; i++))
do
    for((j=i+1 ; j<${#name[*]} ; j++))
    do
        if [ ${name[$i]} -gt ${name[$j]} ]
        then
            temp=${name[$j]}
            name[$j]=${name[$i]}
            name[$i]=$temp
        fi
    done
done

for i in ${name[@]}
do
    echo -n "$i "
done

