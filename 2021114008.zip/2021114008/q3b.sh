#!/bin/bash
wc --lines < $1

