#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "node.h"
#include "my_dll.h"
int main()
{
    
    my_dll *head;
    head = (my_dll * )malloc(sizeof(my_dll)); //allocating memory for head pointer
    head->root=NULL;

    
    while (1)
    {
        char s[20];
        scanf("%s", s);
        if (strcmp(s, "insert") == 0)
        {
            int i, x;
            scanf("%d", &x);
            insert(head, x);
        }
        else if (strcmp(s, "insert_at") == 0)
        {
            int i, x;
            scanf("%d %d", &x, &i);
            insert_at(head, x, i);
        }
        else if (strcmp(s, "delete_") == 0)
        {
            int i, x;
            scanf("%d", &x);
            delete_(head, x);
        }
        else if (strcmp(s, "find") == 0)
        {
            int i, x;
            scanf("%d", &x);

            printf("%d", find(*head, x));
        }
        else if (strcmp(s, "prune") == 0)
        {
            int i, x;
            prune(head);
        }
        else if (strcmp(s, "print") == 0)
        {
            int i, x;
            print(*head);
        }
        else if (strcmp(s, "print_reverse") == 0)
        {
            int i, x;
            print_reverse(*head);
        }
        else if (strcmp(s, "get_size") == 0)
        {
            int i, x; 
            printf("%d", get_size(*head));
        }
        else if (strcmp(s, "exit")==0)
        {
            return(0);
        }
    }
}