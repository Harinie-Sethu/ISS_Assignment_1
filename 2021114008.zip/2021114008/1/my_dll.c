#include <stdio.h>
#include <stdlib.h>
#include "my_dll.h"
#include "node.h"

void insert(my_dll *list, int x)
{
    struct node *new;
    new = (struct node *)malloc(sizeof(struct node));
    new->next = NULL;
    new->prev = NULL;
    new->data = x;
    // list.root->data = x;

    if (list->root == NULL)
    {
        list->root = new;
        return;
    }

    struct node *temp = list->root;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    temp->next = new;
    new->prev = temp;
    new->next = NULL;
    return;
}

void insert_at(my_dll *list, int x, int i)
{
    struct node *new, *temp2;
    new = (struct node *)malloc(sizeof(struct node));
    new->data = x;
    new->next = NULL;
    new->prev = NULL;
    struct node *temp1 = list->root;

    // I = 0
    if (i == 0)
    {
        if (list->root = NULL) // NO head
        {
            list->root = new;
        }
        else if (list->root->next == NULL) // Only head
        {
        }
        else if (list->root->next->next == NULL)
        {
            new->next = list->root->next;
            list->root = new;
            new->next->next = NULL;
        }
        else // Inserting otherwise
        {
            new->next = list->root->next;
            list->root = new;
        }
    }
    else // I !=0
    {
        while (i != 1)
        {
            temp1 = temp1->next;
            i--;
        }

        if (temp1->next == NULL) // Inserting at end
        {
            temp1->next = new;
            new->prev = temp1;
        }
        else // rest
        {
            temp2 = temp1->next;
            temp2->prev = new;
            new->next = temp2;
            new->prev = temp1;
            temp1->next = new;
        }
    }
    return;
}

void delete_(my_dll *list, int i)
{
    struct node *temp;
    temp = list->root;
    /*while ((i != 1) && (i != 0))
    {
        temp = temp->next;
        i--;
    }

    if (temp->next = NULL)
    {
        if (i == 0)
        {
            temp = list->root->next;
            list->root = NULL;
            temp->next = NULL;
            temp->prev = NULL;
        }
        else if (i == 1)
        {
            temp = list->root->next->next;
            list->root->next->next = NULL;
            temp->next = NULL;
            temp->prev = NULL;
        }
        else
        {
            temp->prev->next = NULL;
            temp->next = NULL;
            temp->prev = NULL;
        }
    }
    else
    {
        if (i == 0)
        {
            temp = list->root->next;
            list->root = list->root->next->next;
            temp->next->prev = list->root;
            temp->next = NULL;
            temp->prev = NULL;
        }
        else if (i == 1)
        {
            temp = list->root->next->next;
            list->root->next->next = temp->next;
            temp->next->prev = list->root->next->next;
            temp->next = NULL;
            temp->prev = NULL;
        }
        else
        {
            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            temp->next = NULL;
            temp->prev = NULL;
        }
    }
    return;*/
    int j = 0;
    while (j < i)
    {
        temp = temp->next;
        j++;
    }
    if (temp == list->root)
    {
        list->root = list->root->next;
        list->root->next->prev = NULL;
    }
    else if (temp == NULL)
    {
        return;
    }
    else if (temp->next == NULL)
    {
        temp->prev->next = NULL;
        free(temp);
    }
    else
    {
        temp->next->prev = temp->prev;
        temp->prev->next = temp->next;
        free(temp);
        /*temp->next = NULL;
        temp->prev = NULL;*/
    }
}

int find(my_dll list, int x)
{
    struct node *temp = list.root;
    int count = 0, flag = 0;
    while (temp->next != NULL)
    {

        if (temp->data == x)
        {
            flag = 0;
            goto begin;
        }
        else
        {
            flag = -1;
        }
        count++;

        temp = temp->next;
    }
begin:

    if (flag == 0)
    {
        return count;
    }
    else
    {
        return -1;
    }
}

void prune(my_dll *list)
{
    //struct node *temp = list->root;
    int counter = 0, i=0;
    /*while (temp->next != NULL)
    {
        if (temp->prev == list->root)
        {
            temp->next = temp->next->next;
            temp->next->next->prev = temp->next;
        }
        if (temp->next == NULL)
        {
            if (counter % 2 == 0)
            {
                temp->prev = temp->prev->prev;
                temp->next = NULL;
            }
            else
            {
                temp->prev->next = NULL;
                temp->prev = NULL;
            }
        }
        else
        {
            if (counter % 2 == 0)
            {
                temp->next = temp->next->next;
                temp->prev = temp->prev->prev;
            }
            else
            {
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                temp->next = NULL;
                temp->prev = NULL;
            }
        }
        counter++;
        temp = temp->next;

        if (temp->next->next == NULL)
            return;
    }
    return;*/
    int x = get_size(*list);
    for(i=x-1; i>0; i--)
    {
        if(i%2!=0)
        {
            delete_(list, i);
        }
    }
}

void print(my_dll list)
{
    struct node *temp = list.root;
    while (temp != NULL)
    {
        printf("%d  ", temp->data);
        temp = temp->next;
    }
}

/*void print_reverse(my_dll list)
{
    struct node *temp = list.root;
    while (temp->next != NULL)
    {
        temp = temp->next;
        if (temp->next == NULL)
        {
            while (temp->prev != list.root)
            {
                printf("%d", temp->data);
                temp = temp->prev;
            }
        }
    }
}*/

void print_reverse(my_dll list)
{
    struct node *temp = list.root;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }
    if (temp->next == NULL)
    {
        while (temp != NULL)
        {
            printf("%d  ", temp->data);
            temp = temp->prev;
        }
    }
    return;
}

int get_size(my_dll list)
{
    struct node *temp = list.root;
    int count = 0;
    while (temp != NULL)
    {
        temp = temp->next;
        count++;
    }
    return count;
}
