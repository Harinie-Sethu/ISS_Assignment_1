I've used ubuntu vs code to run the below codes on my hp laptop.

Running using Makefile:
    $chmod +x Makefile
    $./Makefile

Input Format:
1.c:
    exit
        To exit the program
    
    insert x
        x is an integer you wish to insert

    insert_at x i
        x is an integer you wish to insert
        i is the index position of x
    
    delete_ x
        x is the index position from where you want to delete

    find x
        x is the integer you wish to find

    prune
        deleting odd indexed elements 
           
    print
        To print the list
        
    print_reverse
        to print list in reverse order

    get_size
        to get the size of the list

    

2.c:
ADD n
Input:  N1 N2 N3 ... Nn
        N1 N2 N3 ... Nn
Output: N1 N2 N3 ... Nn

SUB n
Input:  N1 N2 N3 ... Nn
        N1 N2 N3 ... Nn
Output: N1 N2 N3 ... Nn

MOD n
Input:  N1 N2 N3 ... Nn
Output: N

DOT n
Input:  N1 N2 N3 ... Nn
        N1 N2 N3 ... Nn
Output: N


COS n
Input:  N1 N2 N3 ... Nn
        N1 N2 N3 ... Nn
Output: N

        ,where N1 N2 N3 ... Nn are data for Dimensions

3.c (Same Driver Code from Discord WITHOUT bonus)
    makeSong
    createMusicPlayer
    addSongToQueue
    removeSongFromQueue
    playSong
    getCurrentSong
