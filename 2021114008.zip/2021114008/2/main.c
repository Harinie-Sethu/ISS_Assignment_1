#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "complex.h"
//#include"complex.c"

int main()
{
    char input[10];
    int num, i=0;
    scanf("%s %d", input, &num);

    if (strcasecmp(input, "add") == 0)
    {
        complex s1, s2;
        s1.array_Size = num;
        s2.array_Size = num;

        s1.a = (float *)malloc(num * sizeof(float));
        s2.a = (float *)malloc(num * sizeof(float));

        i = 0;
        while (i < num)
        {
            scanf("%f", &s1.a[i]);
            i++;
        }
        i = 0;
        while (i < num)
        {
            scanf("%f", &s2.a[i]);
            i++;
        }

        complex sum;
        // sum.a = (float* )malloc(num*sizeof(float));

        sum = add(s1, s2);

        for (i = 0; i < num; i++)
        {
            printf("%.1f ", sum.a[i]);
        }
    }
    else if (strcasecmp(input, "sub") == 0)
    {
        complex s1, s2;
        s1.array_Size = num;
        s2.array_Size = num;

        s1.a = (float *)malloc(num * sizeof(float));
        s2.a = (float *)malloc(num * sizeof(float));

        i = 0;
        while (i < num)
        {
            scanf("%f", &s1.a[i]);
            i++;
        }
        i = 0;
        while (i < num)
        {
            scanf("%f", &s2.a[i]);
            i++;
        }

        complex diff;
        // sum.a = (float* )malloc(num*sizeof(float));

        diff = sub(s1, s2);

        for (int i = 0; i < num; i++)
        {
            printf("%.1f ", diff.a[i]);
        }
    }
    else if (strcasecmp(input, "mod") == 0)
    {
        complex s1;
        s1.array_Size = num;

        s1.a = (float *)malloc(num * sizeof(float));

        i = 0;
        while (i < num)
        {
            scanf("%f", &s1.a[i]);
            i++;
        }

        float modulo;
        modulo = mod(s1);

        printf("%.1f ", modulo);
    }
    else if (strcasecmp(input, "dot") == 0)
    {
        complex s1, s2;
        s1.array_Size = num;
        s2.array_Size = num;

        s1.a = (float *)malloc(num * sizeof(float));
        s2.a = (float *)malloc(num * sizeof(float));

        i = 0;
        while (i < num)
        {
            scanf("%f", &s1.a[i]);
            i++;
        }
        i = 0;
        while (i < num)
        {
            scanf("%f", &s2.a[i]);
            i++;
        }

        float product;

        product = dot(s1, s2);

        printf("%.1f ", product);
    }
    else if (strcasecmp(input, "cos") == 0)
    {
        complex s1, s2;
        s1.array_Size = num;
        s2.array_Size = num;

        s1.a = (float *)malloc(num * sizeof(float));
        s2.a = (float *)malloc(num * sizeof(float));

        i = 0;
        while (i < num)
        {
            scanf("%f", &s1.a[i]);
            i++;
        }
        i = 0;
        while (i < num)
        {
            scanf("%f", &s2.a[i]);
            i++;
        }

        float soln;
        soln = COS(s1, s2);
        printf("%.1f ", soln);
    }
}