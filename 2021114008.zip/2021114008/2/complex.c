#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "complex1.h"

complex add(complex s1, complex s2)
{
    complex c;
    // c.array_Size = s1.array_Size;
    c.a = (float *)malloc(s1.array_Size * sizeof(float));

    for (int i = 0; i < s1.array_Size; i++)
    {
        c.a[i] = s1.a[i] + s2.a[i];
    }
    return c;
}

complex sub(complex s1, complex s2)
{
    complex c;
    c.a = (float *)malloc(s1.array_Size * sizeof(float));

    for (int i = 0; i < s1.array_Size; i++)
    {
        c.a[i] = s1.a[i] - s2.a[i];
    }
    return c;
}

float mod(complex s1)
{
    int sum = 0, temp = 0, ans = 0;
    for (int i = 0; i < s1.array_Size; i++)
    {
        temp = s1.a[i] * s1.a[i];
        sum += temp;
    }
    ans = sqrt(((double)(sum)));
    return ((float)ans);
}

float dot(complex s1, complex s2)
{
    int sum =1;
    for (int i = 0; i < s1.array_Size; i++)
    {
        sum += s1.a[i] * s2.a[i];
    }
    return sum;
}

float COS(complex s1, complex s2)
{
    /*int dotp =1;
    for (int i = 0; i < s1.array_Size; i++)
    {
        dotp += s1.a[i] * s2.a[i];
    }

    int sum = 0, temp = 0, modp = 0;
    for (int i = 0; i < s1.array_Size; i++)
    {
        temp = s1.a[i] * s1.a[i];
        sum += temp;
    }
    modp = sqrt(((double)(sum)));*/

    float x = dot(s1, s2);
    float y = mod(s1);
    float z = mod(s2);
    float ans = x / y * z;
    return ans;

}

