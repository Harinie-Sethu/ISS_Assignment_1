#include <stdio.h>
#include <stdlib.h>
#ifndef COMPLEX
#define COMPLEX

typedef struct complex
{
    float *a;
    int array_Size;
}complex;

complex add(complex s1, complex s2);
complex sub(complex s1, complex s2);
float mod(complex s1);
float dot(complex s1, complex s2);
float COS(complex s1, complex s2);
#endif