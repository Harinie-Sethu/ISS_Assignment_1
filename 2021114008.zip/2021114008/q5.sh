#!/bin/bash
read name
revstr=`echo $name | rev`
echo "$revstr"

final=$(echo "$revstr" | tr "A-Za-z" "B-ZAb-za")
echo $final

len=${#name}
lenf=`expr $len/2`
echo ${revstr:lenf:len}${name:lenf:len}

