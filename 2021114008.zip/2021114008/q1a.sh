#!/bin/bash
grep -v '^$' quotes.txt

